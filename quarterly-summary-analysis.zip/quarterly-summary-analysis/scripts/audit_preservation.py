#!/usr/bin/env python3
"""Read-only audit of numeric cells, formulas and WPS in-cell images."""
import argparse
from decimal import Decimal
import json
import posixpath
import re
import sys
import zipfile
from xml.etree import ElementTree as E

S = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
R = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'

def read(path):
    with zipfile.ZipFile(path) as z:
        parts = {n: z.read(n) for n in z.namelist()}
    book = E.fromstring(parts['xl/workbook.xml'])
    rels = {e.get('Id'): e.get('Target') for e in E.fromstring(parts['xl/_rels/workbook.xml.rels'])}
    numeric, formulas, pictures, failures = {}, {}, {}, []
    for sheet in book.find(S + 'sheets'):
        target = rels[sheet.get(R + 'id')]
        target = target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.join('xl', target))
        root = E.fromstring(parts[target])
        for cell in root.iter(S + 'c'):
            key = (sheet.get('name'), cell.get('r'))
            f, v = cell.find(S + 'f'), cell.find(S + 'v')
            if f is not None:
                formula = f.text or ''
                formulas[key] = formula
                if 'DISPIMG' in formula:
                    match = re.search(r'DISPIMG\(\s*"([^"]+)"', formula)
                    if not match:
                        failures.append(f'Unrecognized image formula: {key}')
                    else:
                        pictures[key] = match.group(1)
                        expected = '=' + formula.replace('_xlfn.', '')
                        if cell.get('t') != 'str' or v is None or v.text != expected:
                            failures.append(f'Invalid WPS image cache: {key}')
            elif cell.get('t', 'n') == 'n' and v is not None and v.text:
                numeric[key] = Decimal(v.text)
    library = {}
    if 'xl/cellimages.xml' in parts:
        links = {e.get('Id'): e.get('Target') for e in E.fromstring(parts['xl/_rels/cellimages.xml.rels'])}
        for entry in E.fromstring(parts['xl/cellimages.xml']):
            prop = next((e for e in entry.iter() if e.tag.endswith('}cNvPr')), None)
            blip = next((e for e in entry.iter() if e.tag.endswith('}blip')), None)
            if prop is None or blip is None:
                continue
            link = links.get(blip.get(R + 'embed'))
            if not link:
                continue
            media = link.lstrip('/') if link.startswith('/') else posixpath.normpath(posixpath.join('xl', link))
            if media in parts:
                library[prop.get('name')] = parts[media]
    for key, image_id in pictures.items():
        if image_id not in library:
            failures.append(f'Missing local image: {key}')
    for name, data in parts.items():
        if re.fullmatch(r'xl/drawings/drawing\d+\.xml', name):
            root = E.fromstring(data)
            if any(e.tag.endswith('}pic') for e in root.iter()):
                failures.append(f'Floating image present: {name}')
    return numeric, formulas, pictures, library, failures

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source')
    parser.add_argument('output')
    args = parser.parse_args()
    a, b = read(args.source), read(args.output)
    failures = list(b[4])
    for label, old, new in [('numeric', a[0], b[0]), ('formula', a[1], b[1])]:
        for key, value in old.items():
            if new.get(key) != value:
                failures.append(f'Changed/missing {label}: {key}')
    for key, image_id in a[2].items():
        new_id = b[2].get(key)
        if new_id is None or a[3].get(image_id) != b[3].get(new_id):
            failures.append(f'Changed/missing source image: {key}')
    print(json.dumps({'ok': not failures, 'numeric_cells': len(b[0]),
                      'in_cell_images': len(b[2]), 'failures': failures,
                      'note': 'Read-only structural audit; native display and text layout still require visual verification.'},
                     ensure_ascii=False, indent=2))
    return 1 if failures else 0

if __name__ == '__main__':
    sys.exit(main())
