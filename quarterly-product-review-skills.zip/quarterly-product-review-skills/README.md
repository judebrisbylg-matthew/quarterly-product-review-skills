# 季度复盘分析 skill

本仓库封装季度商品复盘的已确认流程。目前包含一个 skill：**数据分析**，对应步骤一的数据填写；步骤二“总结分析”尚未制作。

- [流程可视化 HTML](docs/step-1-workflow.html)：下载后用浏览器打开，可离线使用。
- [安装与使用](docs/usage.md)
- [数据分析 skill](skills/quarterly-data-analysis/SKILL.md)
- [指标与模板映射](skills/quarterly-data-analysis/references/data-contract.md)

输入：季度分析模板 XLSX + 运营季度复盘 XLSX。输出：保留模板版式、含当前线上商品图及已核验指标的数据填写稿。问题、方案、对标及总结留待步骤二。

本仓库不包含真实运营报表、商品素材、账号凭据或个人绝对路径。脚本仅辅助读取汇总，不是无人值守的全流程程序。
