#!/usr/bin/env python3
"""Read quarterly XLSX detail, aggregate by parent/SKC. Never writes workbook."""
import argparse
import json
from numbers import Real
import openpyxl

FIELDS = {
    'parent': ['父asin', '父ASIN'], 'skc': ['skc', 'SKC'], 'type': ['广告类型'],
    'impressions': ['曝光量'], 'clicks': ['点击'], 'spend': ['花费'],
    'orders': ['广告订单'], 'five_seconds': ['5秒观看次数'],
    'completions': ['视频完播的次数', '视频完播次数'], 'visible': ['可见次数'],
    'sales': ['广告销售额', '销售额', '广告销售额(USD)', '广告销售额（USD）'],
}
THRESHOLDS = {'image_ctr': (.005, False), 'cvr': (.05, False),
              'acos': (.25, True), 'roi': (4, False), 'video_ctr': (.007, False),
              'five_second_rate': (.08, False), 'completion_rate': (.24, False)}

def ratio(totals, numerator, denominator):
    n, d = totals[numerator], totals[denominator]
    return n / d if n is not None and d is not None and d > 0 else None

def aggregate(rows, columns):
    totals = {}
    for key in list(FIELDS)[3:]:
        values = [r[columns[key]] for r in rows]
        totals[key] = (sum(values) if values and all(isinstance(v, Real) and not isinstance(v, bool) for v in values) else None)
    metrics = {name: ratio(totals, a, b) for name, a, b in [
        ('ctr', 'clicks', 'impressions'), ('cvr', 'orders', 'clicks'),
        ('acos', 'spend', 'sales'), ('roi', 'sales', 'spend'),
        ('five_second_rate', 'five_seconds', 'impressions'),
        ('completion_rate', 'completions', 'visible')]}
    return {'row_count': len(rows), 'totals': totals, 'metrics': metrics}

def run(path, parent, sheet, sales_header=None):
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    rows = iter(wb[sheet].values)
    headers = [str(x).strip() if x is not None else '' for x in next(rows)]
    aliases = dict(FIELDS)
    if sales_header:
        aliases['sales'] = [sales_header]
    columns = {}
    for key, names in aliases.items():
        matches = [i for i, h in enumerate(headers) if h in names]
        if len(matches) != 1:
            raise ValueError(f'字段 {key} 匹配到 {len(matches)} 列；请核对表头。销售额可使用 --sales-header 指定。')
        columns[key] = matches[0]
    selected = [r for r in rows if str(r[columns['parent']]).strip() == parent]
    if not selected:
        raise ValueError('未找到指定父 ASIN')
    if any(not r[columns['skc']] for r in selected):
        raise ValueError('本款存在缺失 SKC，请核实后再汇总')
    def scope(rs):
        return {'all_ads': aggregate(rs, columns),
                'video': aggregate([r for r in rs if str(r[columns['type']]).strip() == '视频'], columns)}
    result = {'parent': parent, 'source': str(path), 'sheet': sheet,
              'parent_totals': scope(selected),
              'skcs': {sk: scope([r for r in selected if r[columns['skc']] == sk])
                       for sk in sorted({r[columns['skc']] for r in selected})},
              'missing_display': '—', 'notes': ['null 表示不可计算或缺失，不是0；图片及A+默认采用全部广告口径。']}
    wb.close()
    return result

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('workbook')
    parser.add_argument('--parent', required=True)
    parser.add_argument('--sheet', default='近2年的广告活动数据')
    parser.add_argument('--sales-header')
    args = parser.parse_args()
    print(json.dumps(run(args.workbook, args.parent, args.sheet, args.sales_header), ensure_ascii=False, indent=2))
